PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS vehicles (
    vehicle_id INTEGER PRIMARY KEY AUTOINCREMENT,
    registration_number TEXT NOT NULL UNIQUE,
    vehicle_type TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS parking_slots (
    slot_id INTEGER PRIMARY KEY AUTOINCREMENT,
    slot_number TEXT NOT NULL UNIQUE,
    slot_type TEXT NOT NULL DEFAULT 'STANDARD',
    status TEXT NOT NULL DEFAULT 'AVAILABLE'
        CHECK(status IN ('AVAILABLE','OCCUPIED'))
);

CREATE TABLE IF NOT EXISTS parking_sessions (
    session_id INTEGER PRIMARY KEY AUTOINCREMENT,
    vehicle_id INTEGER NOT NULL,
    slot_id INTEGER NOT NULL,
    entry_time TEXT NOT NULL,
    exit_time TEXT,
    duration_minutes INTEGER,
    amount_due INTEGER,
    session_status TEXT NOT NULL DEFAULT 'ACTIVE'
        CHECK(session_status IN ('ACTIVE','COMPLETED')),
    FOREIGN KEY(vehicle_id) REFERENCES vehicles(vehicle_id),
    FOREIGN KEY(slot_id) REFERENCES parking_slots(slot_id)
);

CREATE TABLE IF NOT EXISTS payments (
    payment_id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER NOT NULL UNIQUE,
    amount INTEGER NOT NULL CHECK(amount >= 0),
    payment_time TEXT,
    payment_status TEXT NOT NULL DEFAULT 'PENDING'
        CHECK(payment_status IN ('PENDING','PAID','FAILED')),
    FOREIGN KEY(session_id) REFERENCES parking_sessions(session_id)
);

CREATE INDEX IF NOT EXISTS idx_vehicle_registration ON vehicles(registration_number);
CREATE INDEX IF NOT EXISTS idx_active_sessions ON parking_sessions(vehicle_id, session_status);
CREATE INDEX IF NOT EXISTS idx_session_status ON parking_sessions(session_status);
